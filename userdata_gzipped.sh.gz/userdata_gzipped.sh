#! /bin/sh

touch /script_executed
env >> /script_executed
